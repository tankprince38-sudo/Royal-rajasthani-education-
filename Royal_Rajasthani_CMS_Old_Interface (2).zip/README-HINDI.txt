ROYAL RAJASTHANI EDUCATION — CMS PACKAGE

यह पैकेज पुरानी वेबसाइट की रंग-रूप/डिजाइन शैली को बनाए रखते हुए विषय और अध्याय को catalog.json से दिखाता है।

GitHub main branch में इन paths को upload करें: index.html, admin/index.html, admin/config.yml, content/catalog.json. uploads/pdfs खाली folder है; CMS PDF upload करते समय इसे बनाएगा।

महत्त्वपूर्ण सुरक्षा/लॉगिन नोट:
Decap CMS का GitHub backend अकेले admin login नहीं चलाता। GitHub OAuth/authentication service अलग से configure करनी होगी। कोई Client Secret इस repository, HTML, config.yml या सार्वजनिक जगह पर न डालें। Login setup पूरा होने तक /admin/ पर login काम नहीं करेगा।

पुरानी index.html का backup रखें। यदि अभी public interface बदलना नहीं चाहते, तो index.html replace न करें—लेकिन तब CMS से जोड़े गए विषय/अध्याय public page पर नहीं दिखेंगे। इस पैकेज की index.html पुरानी homepage शैली को बनाए रखते हुए catalog से सामग्री पढ़ती है।
